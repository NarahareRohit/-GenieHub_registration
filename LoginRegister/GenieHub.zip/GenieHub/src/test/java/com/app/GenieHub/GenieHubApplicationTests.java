package com.app.GenieHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenieHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
